import './App.css';
import Calculadora from './componentes/Calculadora';

function App() {
  return (
    <div className="App">
      <Calculadora catetoA='Cateto A' catetoB='Cateto B' hipotenusa=''></Calculadora>
    </div>
  );
}

export default App;
