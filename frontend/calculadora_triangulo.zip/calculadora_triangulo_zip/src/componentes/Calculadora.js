import React, { Component } from 'react'

export default class Calculadora extends Component {

    constructor(props){
        super(props);
        this.state = {
            catetoA_valor: "",
            catetoB_valor: "",
            hipotenusa_valor: ""
        }
        this.setValueCatetoA = this.setValueCatetoA.bind(this)
        this.setValueCatetoB = this.setValueCatetoB.bind(this)
        this.setValueHipotenusa = this.setValueHipotenusa.bind(this)
    }

    calcular(){
        let de_para = `${this.state.catetoA_valor}&${this.state.catetoB_valor}`;
        let url = `http://127.0.0.1:8000/${de_para}/`;
        fetch(url)
        .then(res=>{
            return res.json()
        })
        .then(json=>{
            this.setValueHipotenusa(json.hipotenusa)
        })
    }

    setValueCatetoA = (event)=>{
        this.setState({catetoA_valor: event.target.value});
    }

    setValueCatetoB = (event)=>{
        this.setState({catetoB_valor: event.target.value});
    }

    setValueHipotenusa(hipotenusa){
        this.setState({hipotenusa_valor: hipotenusa})
    }

    render(){
        return (
            <div className="calculadora">
                <h2>{this.props.catetoA}</h2>
                <input type="text" onChange={this.setValueCatetoA}></input>
                <h2>{this.props.catetoB}</h2>
                <input type="text" onChange={this.setValueCatetoB}></input>
                <input type="button" value="Calcular" onClick={(event)=>{this.calcular()}}></input>
                <h2>Hipotenusa é {this.state.hipotenusa_valor}</h2>
            </div>
        )
    }
}